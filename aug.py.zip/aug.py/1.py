import os

# Define paths to both directories
 # Update with the correct path
forge_directory_path = r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\forge'  # Update with the correct path

# Function to rename files sequentially in a given directory
def rename_files(directory_path):
    # List all files in the directory
    files = sorted(os.listdir(directory_path))  # Sorting to maintain order

    # Iterate over the files and rename them sequentially (1, 2, 3, ...)
    for i, filename in enumerate(files, 1):
        # Get the file extension
        file_extension = os.path.splitext(filename)[1]

        # Define the new filename (1, 2, 3, ...)
        new_filename = f"{i}{file_extension}"

        # Construct full paths
        old_file = os.path.join(directory_path, filename)
        new_file = os.path.join(directory_path, new_filename)

        # Rename the file
        os.rename(old_file, new_file)
        print(f"Renamed: {filename} -> {new_filename}")

# Rename files in both 'real' and 'forge' directories

rename_files(forge_directory_path)
