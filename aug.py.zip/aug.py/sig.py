# Import necessary libraries for image preprocessing and deep learning model setup
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np
import cv2
import os

# Set image size for resizing
image_size = (128, 128)

# Function to load and preprocess images
def load_images_from_folder(folder, label, image_size):
    images = []
    labels = []
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)  # Load as grayscale
        if img is not None:
            img = cv2.resize(img, image_size)  # Resize the image
            img = img / 255.0  # Normalize pixel values to [0, 1]
            images.append(img)
            labels.append(label)
    return np.array(images), np.array(labels)

# Load genuine and forged signatures for training
genuine_folder = os.path.join(train_folder, 'genuine')
forged_folder = os.path.join(train_folder, 'forge')

genuine_images, genuine_labels = load_images_from_folder(genuine_folder, label=1, image_size=image_size)  # Label 1 for genuine
forged_images, forged_labels = load_images_from_folder(forged_folder, label=0, image_size=image_size)    # Label 0 for forged

# Combine the images and labels from both categories
X_train = np.concatenate([genuine_images, forged_images], axis=0)
y_train = np.concatenate([genuine_labels, forged_labels], axis=0)

# Reshape the images to fit the input format of the CNN (batch_size, height, width, channels)
X_train = X_train.reshape(-1, image_size[0], image_size[1], 1)

# Check the shape of the data
X_train.shape, y_train.shape