import torch
import torch.nn.functional as F
from torchvision import transforms
from PIL import Image
import os

# Define the CNN Backbone
class SignatureCNN(torch.nn.Module):
    def __init__(self):
        super(SignatureCNN, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 64, kernel_size=10)
        self.conv2 = torch.nn.Conv2d(64, 128, kernel_size=7)
        self.conv3 = torch.nn.Conv2d(128, 128, kernel_size=4)
        self.conv4 = torch.nn.Conv2d(128, 256, kernel_size=4)
        self.fc1 = torch.nn.Linear(256 * 6 * 6, 4096)  # Adjust based on your input size
        self.fc2 = torch.nn.Linear(4096, 128)  # Embedding output size

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv3(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv4(x))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Define the Siamese Network
class SiameseNetwork(torch.nn.Module):
    def __init__(self):
        super(SiameseNetwork, self).__init__()
        self.cnn = SignatureCNN()

    def forward(self, input1, input2):
        output1 = self.cnn(input1)
        output2 = self.cnn(input2)
        return output1, output2

# Load the model
model = SiameseNetwork()
model.load_state_dict(torch.load('siamese_signature_verification.pth'))  # Load your trained model
model.eval()  # Set the model to evaluation mode

# Define the transformation (same as during training)
transform = transforms.Compose([
    transforms.Resize((105, 105)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor()
])

def evaluate(model, test_pairs, labels, threshold=0.6):
    correct = 0
    total = len(test_pairs)

    for i, (img1_path, img2_path) in enumerate(test_pairs):
        # Check if the images exist
        if not os.path.exists(img1_path):
            print(f"Warning: {img1_path} not found!")
            continue
        if not os.path.exists(img2_path):
            print(f"Warning: {img2_path} not found!")
            continue

        # Process the image pair
        img1 = Image.open(img1_path).convert("L")
        img2 = Image.open(img2_path).convert("L")
        img1 = transform(img1).unsqueeze(0)  # Add batch dimension
        img2 = transform(img2).unsqueeze(0)  # Add batch dimension

        with torch.no_grad():
            output1, output2 = model(img1, img2)

        # Calculate Euclidean distance
        euclidean_distance = F.pairwise_distance(output1, output2)
        prediction = 1 if euclidean_distance.item() > threshold else 0  # Adjust threshold as needed

        # Print the prediction and whether it was correct
        if prediction == labels[i]:
            correct += 1
            print(f"Prediction: {prediction} - Correct")
        else:
            print(f"Prediction: {prediction} - Incorrect")

    accuracy = (correct / total) * 100 if total > 0 else 0  # To avoid division by zero
    print(f"Accuracy: {accuracy:.2f}%")

# Example usage:
test_pairs = [
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\1.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\forge\1.png'),
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\1.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\2.png'),
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\1.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\forge\2.png'),
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\1.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\3.png'),
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\7.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\forge\2.png'),
    (r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\7.png', r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\8.png'),
    # Add more image pairs here
]

labels = [1, 0, 1, 0, 1, 0]  # Corresponding labels for each pair (0 for genuine, 1 for forged)

evaluate(model, test_pairs, labels)


 