import os

# Define the path to the directory containing the files
directory_path = r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real'  # Change this to your directory path

# List all files in the directory
files = sorted(os.listdir(directory_path))  # Sorting to maintain order

# Iterate over the files and rename them sequentially (1, 2, 3, ...)
for i, filename in enumerate(files, 1):
    # Get the file extension
    file_extension = os.path.splitext(filename)[1]
    
    # Define the new filename (1, 2, 3, ...)
    new_filename = f"{i}{file_extension}"
    
    # Construct full paths
    old_file = os.path.join(directory_path, filename)
    new_file = os.path.join(directory_path, new_filename)
    
    # Rename the file
    os.rename(old_file, new_file)
    print(f"Renamed: {filename} -> {new_filename}")
