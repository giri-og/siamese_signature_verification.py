import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torch.nn.functional as F
from PIL import Image
import numpy as np

import os

# 1. Define the CNN Backbone

class SignatureCNN(nn.Module):
    def __init__(self):
        super(SignatureCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=10)  # assuming grayscale images
        self.conv2 = nn.Conv2d(64, 128, kernel_size=7)
        self.conv3 = nn.Conv2d(128, 128, kernel_size=4)
        self.conv4 = nn.Conv2d(128, 256, kernel_size=4)
        self.fc1 = nn.Linear(256 * 6 * 6, 4096)  # Adjust based on your input size
        self.fc2 = nn.Linear(4096, 128)  # Embedding output size

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv3(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv4(x))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 2. Define the Siamese Network
class SiameseNetwork(nn.Module):
    def __init__(self):
        super(SiameseNetwork, self).__init__()
        self.cnn = SignatureCNN()

    def forward(self, input1, input2):
        output1 = self.cnn(input1)
        output2 = self.cnn(input2)
        return output1, output2

# 3. Define Contrastive Loss Function
class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, output1, output2, label):
        euclidean_distance = F.pairwise_distance(output1, output2)
        loss = torch.mean((1 - label) * torch.pow(euclidean_distance, 2) +
                          (label) * torch.pow(torch.clamp(self.margin - euclidean_distance, min=0.0), 2))
        return loss

# 4. Dataset Preparation
class SignatureDataset(Dataset):
    def __init__(self, image_pairs, labels, transform=None):
        self.image_pairs = image_pairs
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.image_pairs)

    def __getitem__(self, idx):
        img1_path, img2_path = self.image_pairs[idx]
        
        # Check if both files exist before trying to open them
        if not os.path.exists(img1_path):
            print(f"Warning: {img1_path} not found!")
            img1 = Image.new("L", (105, 105))  # Create a blank image as a placeholder
        else:
            img1 = Image.open(img1_path).convert("L")  # Convert to grayscale
        
        if not os.path.exists(img2_path):
            print(f"Warning: {img2_path} not found!")
            img2 = Image.new("L", (105, 105))  # Create a blank image as a placeholder
        else:
            img2 = Image.open(img2_path).convert("L")

        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        label = torch.tensor(self.labels[idx], dtype=torch.float32)
        return img1, img2, label

# 5. Hyperparameters and DataLoader
genuine_path = 'C:/Users/potnu/Downloads/Dataset_Signature_Final/Dataset/dataset1/real'

forged_path = 'C:/Users/potnu/Downloads/Dataset_Signature_Final/Dataset/dataset1/forge'

# Assuming images are named sequentially, for example: 1.png, 2.png, etc.
genuine_images = [os.path.join(genuine_path, f"{i}.PNG") for i in range(1, 11)]  # Adjust based on actual files
forged_images = [os.path.join(forged_path, f"{i}.PNG") for i in range(1, 11)]  # Adjust based on actual files

# Create pairs: For simplicity, let's pair the first genuine image with the second genuine image
pairs = []
labels = []

# Add genuine pairs (label = 0)
for i in range(len(genuine_images)):
    for j in range(i + 1, len(genuine_images)):  # Pair up all genuine images with each other
        pairs.append((genuine_images[i], genuine_images[j]))
        labels.append(0)

# Add forged pairs (label = 1)
for i in range(len(genuine_images)):
    for j in range(len(forged_images)):  # Pair each genuine image with a forged image
        pairs.append((genuine_images[i], forged_images[j]))
        labels.append(1)

# Transformations
transform = transforms.Compose([transforms.Resize((105, 105)),
                                transforms.ToTensor()])

# Create the dataset and dataloader
dataset = SignatureDataset(image_pairs=pairs, labels=labels, transform=transform)
dataloader = DataLoader(dataset, shuffle=True, batch_size=16)

# 6. Initialize Model, Loss, Optimizer
model = SiameseNetwork()
criterion = ContrastiveLoss(margin=1.0)
optimizer = optim.Adam(model.parameters(), lr=0.0005)

# 7. Training Loop
num_epochs = 20
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

for epoch in range(num_epochs):
    total_loss = 0
    for img1, img2, label in dataloader:
        img1, img2, label = img1.to(device), img2.to(device), label.to(device)
        
        optimizer.zero_grad()
        output1, output2 = model(img1, img2)
        loss = criterion(output1, output2, label)
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
    
    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {total_loss/len(dataloader):.4f}")

# 8. Save the Model
torch.save(model.state_dict(), 'siamese_signature_verification.pth')
