import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from PIL import Image
import os

# 1. Define the CNN Backbone
class SignatureCNN(nn.Module):
    def __init__(self):
        super(SignatureCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=10)
        self.conv2 = nn.Conv2d(64, 128, kernel_size=7)
        self.conv3 = nn.Conv2d(128, 128, kernel_size=4)
        self.conv4 = nn.Conv2d(128, 256, kernel_size=4)
        self.fc1 = nn.Linear(256 * 6 * 6, 4096)  # Adjust based on your input size
        self.fc2 = nn.Linear(4096, 128)  # Embedding output size

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv3(x))
        x = F.max_pool2d(x, (2, 2))
        x = F.relu(self.conv4(x))
        x = x.view(x.size(0), -1)  # Flatten the tensor
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 2. Define the Siamese Network
class SiameseNetwork(nn.Module):
    def __init__(self):
        super(SiameseNetwork, self).__init__()
        self.cnn = SignatureCNN()

    def forward(self, input1, input2):
        output1 = self.cnn(input1)
        output2 = self.cnn(input2)
        return output1, output2

# 3. Load the Model
model = SiameseNetwork()
model.load_state_dict(torch.load('siamese_signature_verification.pth'))  # Load your trained model
model.eval()  # Set the model to evaluation mode

# 4. Define Transformation (same as during training)
transform = transforms.Compose([transforms.Resize((105, 105)),
                                transforms.ToTensor()])

# 5. Load and Test New Image Pair
def verify_signature(image1_path, image2_path):
    if not os.path.exists(image1_path):
        print(f"Warning: {image1_path} not found!")
        return None
    if not os.path.exists(image2_path):
        print(f"Warning: {image2_path} not found!")
        return None

    # Load and transform the images
    img1 = Image.open(image1_path).convert("L")
    img2 = Image.open(image2_path).convert("L")

    img1 = transform(img1).unsqueeze(0)  # Add batch dimension
    img2 = transform(img2).unsqueeze(0)  # Add batch dimension

    # Run the images through the network
    with torch.no_grad():  # Disable gradient calculations during inference
        output1, output2 = model(img1, img2)

    # Calculate Euclidean distance
    euclidean_distance = F.pairwise_distance(output1, output2)
    print(f"Euclidean Distance: {euclidean_distance.item()}")

    # Set a threshold for similarity (adjust based on model performance)
    threshold = 0.6  # This is an arbitrary threshold, can be fine-tuned

    if euclidean_distance.item() < threshold:
        print("The signatures are likely genuine.")
    else:
        print("The signatures are likely forged.")

# Example usage:
image1 = r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\1.png'  # Path to the first signature
image2 = r'C:\Users\potnu\Downloads\Dataset_Signature_Final\Dataset\dataset1\real\2.png'  # Path to the second signature

verify_signature(image1, image2)
